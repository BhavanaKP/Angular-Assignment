import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LogInComponent } from './components/log-in/log-in.component';
import { HomeComponent } from './components/home/home.component';

const routes: Routes = [];

@NgModule({
  imports: [RouterModule.forRoot([
    { path: 'log-in', component: LogInComponent },
    { path: '', component: HomeComponent },
    { path: '**', redirectTo: '/' }
  ])],
  exports: [RouterModule]
})
export class AppRoutingModule {
  static forRoot(arg0: any): any {
    throw new Error("Method not implemented.");
  }
}
